#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <windows.h>
#include <io.h>

using namespace std;

//-----------------------------------------------------------------------------
#define HelpText \
"Usage:\n\
  <xml> [<slic3r> <script> <--verbose>]\n\n\
  xml        XML filename. Can be entered without extension.\n\
  slic3r     Executable filename of Slic3r (default: \"Slic3r\").\n\
  script     Python script filename (default: \"merge.py\").\n\
  --verbose  Python script's third argument (default: \"\").\n\
  ?          Usage text.\n\
  q          Quit.\n\n"
//-----------------------------------------------------------------------------
typedef struct STLINIPair
{
	string STLFileName;
	string INIFileName;
	STLINIPair(const string &s):STLFileName(s)
	{
	}
} STLINIPAIR;
//-----------------------------------------------------------------------------
string GetPathNameOrExt(string FullPath, const bool Ext = false)
{
	if (FullPath == "") return FullPath;
	string::size_type i = FullPath.rfind("\\");
	if (i != string::npos)
	if (i < FullPath.length() - 1)
		FullPath = FullPath.substr(i + 1);
	else
		FullPath = "";
	bool DotFound = (i = FullPath.rfind(".")) != string::npos;
	if (Ext)
	{
		if (DotFound  && i < FullPath.length() - 1)
			FullPath = FullPath.substr(i + 1);
		else
			FullPath = "";
	}
	else if (DotFound) FullPath.erase(i);
	return FullPath;
}
//-----------------------------------------------------------------------------
// Without case sensitivity
int GetSubstringPos(const char *Str, const char *Substr)
{
	if (!Str || !Substr) return -1;
	size_t len1 = strlen(Str);
	size_t len2 = strlen(Substr);
	if (!len1 || !len2 || (len1 < len2)) return -1;
	for (size_t i = 0; i <= (len1 - len2); i++)
		if (!strnicmp(&Str[i], Substr, len2)) return (int)i;
	return -1;
}
//-----------------------------------------------------------------------------
// Currently, requires the structure you provided
string GetSTLINIFileNamesFromXMLFile(string XMLFileName, vector<STLINIPAIR> &STLINIPairs)
{
	string ExtOnly = GetPathNameOrExt(XMLFileName, true);
	if (ExtOnly == "") XMLFileName += ".xml";
	ifstream XMLFile(XMLFileName.c_str());
	if (!XMLFile.is_open())	return "Cannot open XML file \"" + XMLFileName + "\".";
	bool STLEntryFound = false;
	string Line;
	while (getline(XMLFile, Line))
	{
		if (GetSubstringPos(Line.c_str(),  "<stl>") != -1) STLEntryFound = true;
		else
		if (GetSubstringPos(Line.c_str(), "</stl>") != -1) STLEntryFound = false;
		if (STLEntryFound)
		{
			int b = GetSubstringPos(Line.c_str(), "<file>");
			int e = GetSubstringPos(Line.c_str(), "</file>");
			if (b != -1 && e != -1 && b < e)
			{
				// 6 is length of "<file>"
				b += 6;
				Line = Line.substr(b, e - b);
				if (access(Line.c_str(), 0) == 0) STLINIPairs.push_back(STLINIPAIR(Line));
				continue;
			}
			b = GetSubstringPos(Line.c_str(), "<settings>");
			e = GetSubstringPos(Line.c_str(), "</settings>");
			if (b != -1 && e != -1 && b < e)
			{
                // 10 is length of "<settings>"
				b += 10;
				Line = Line.substr(b, e - b);
				if (access(Line.c_str(), 0) == 0)
				    if (STLINIPairs.size()) STLINIPairs.back().INIFileName = Line;
			}
		}
	}
	XMLFile.close();
	if (STLINIPairs.empty()) return "STL files are not accessible.";
	return "";
}
//-----------------------------------------------------------------------------
bool LaunchSlic3rForSTLFiles(const string &Slic3rName, const vector<STLINIPAIR> &STLINIPairs)
{
	if (!STLINIPairs.size()) return false;
	char CmdLineBuf[MAX_PATH] = {0};
	string CmdLine;
	PROCESS_INFORMATION ProcInfo;
	STARTUPINFOA StartupInfo;
	ZeroMemory(&StartupInfo, sizeof(StartupInfo));
	StartupInfo.cb = sizeof(StartupInfo);
	string GCODEFileName;
	cout << Slic3rName << endl;
	for (vector<STLINIPAIR>::size_type i = 0; i < STLINIPairs.size(); i++)
	{
		CmdLine = Slic3rName + " \"" + STLINIPairs[i].STLFileName + "\"";
		if (STLINIPairs[i].INIFileName != "") CmdLine += (" --load \"" + STLINIPairs[i].INIFileName + "\"");
		if (CmdLine.length() > MAX_PATH - 1)
		{
			cout << " Too long command line: " << CmdLine << ".\n";
			return false;
		}
		strcpy(CmdLineBuf, CmdLine.c_str());
		string::size_type j = STLINIPairs[i].STLFileName.rfind(".");
		if (j != string::npos)
			GCODEFileName = STLINIPairs[i].STLFileName.substr(0, j) + ".gcode";
		else
			GCODEFileName = STLINIPairs[i].STLFileName + ".gcode";
		DeleteFileA(GCODEFileName.c_str());
		if (CreateProcessA(NULL, CmdLineBuf, NULL, NULL, FALSE,	0, NULL, NULL, &StartupInfo, &ProcInfo))
		{
			cout << " Processing " << STLINIPairs[i].STLFileName << "...\n";
			WaitForSingleObject(ProcInfo.hProcess, INFINITE);
			CloseHandle(ProcInfo.hThread);
			CloseHandle(ProcInfo.hProcess);
			if (access(GCODEFileName.c_str(), 0) == 0)
				cout << " Processed.\n";
			else
				cout << " Could not process " << STLINIPairs[i].STLFileName << ".\n";
		}
		else
		{   
			cout << " Could not launch " << Slic3rName << ".\n";
			return false;
		}
	}
	return true;
}
//-----------------------------------------------------------------------------
void RunPythonScriptForGCODEFiles(const string &ScriptName, const vector<STLINIPAIR> &STLINIPairs, const string &verbose)
{
	// There should be at least 2 GCODE files
	if (STLINIPairs.size() < 2) return;
	vector<string> FileNamesDeleted;
	SHELLEXECUTEINFOA ShExecInfo;
	ZeroMemory(&ShExecInfo, sizeof(ShExecInfo));
	ShExecInfo.cbSize = sizeof(ShExecInfo);
	ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	ShExecInfo.lpVerb = "open";
	string PythonOutFileName, SecondFileName, Parameters;
	string NameOnly = GetPathNameOrExt(STLINIPairs[0].STLFileName);
	bool Success = true;
	PythonOutFileName = string(NameOnly) + ".gcode";
	cout << ScriptName << endl;
	for (vector<STLINIPAIR>::size_type i = 1; i < STLINIPairs.size(); i++)
	{
		NameOnly = GetPathNameOrExt(STLINIPairs[i].STLFileName);
		SecondFileName = NameOnly + ".gcode";
		Parameters = PythonOutFileName + " " + SecondFileName + " " + verbose;
		ShExecInfo.lpFile = ScriptName.c_str();
		ShExecInfo.lpParameters = Parameters.c_str();
		DWORD ExitCode = 1;
		if (ShellExecuteExA(&ShExecInfo))
		{
			cout << " Processing " << PythonOutFileName + " " + SecondFileName << "...\n";
			WaitForSingleObject(ShExecInfo.hProcess, INFINITE);
			GetExitCodeProcess(ShExecInfo.hProcess, &ExitCode);
			CloseHandle(ShExecInfo.hProcess);
			if (ExitCode)
			{
				cout << " Could not process " << PythonOutFileName + " " + SecondFileName << ".\n";
				Success = false;
			}
			else
				cout << " Processed.\n";
		}
		else
		{
			cout << " Could not run " << ScriptName << ".\n";
			return;
		}
		NameOnly = GetPathNameOrExt(PythonOutFileName);
		PythonOutFileName = NameOnly + "." + SecondFileName;
		if (!ExitCode)
			if (i < STLINIPairs.size() - 1) FileNamesDeleted.push_back(PythonOutFileName);
	}
	if (Success) cout << " Final combined file: " << PythonOutFileName << ".\n";
	if (!FileNamesDeleted.size()) return;
	for (vector<string>::size_type i = 0; i < FileNamesDeleted.size(); i++)
		DeleteFileA(FileNamesDeleted[i].c_str());
}
//-----------------------------------------------------------------------------
int main(int argc, char* argv[])
{
	vector<STLINIPAIR> STLINIPairs;
	string XMLFileName, Slic3rName, PythonScriptName, Verbose, ErrorMsg, Line, ArgV;
	if (argc < 2) Line = "?";
	if (argc > 1) Line = string(argv[1]);
	if (argc > 2) Line += (" " +string(argv[2]));
	if (argc > 3) Line += (" " +string(argv[3]));
	if (argc > 4) Line += (" " +string(argv[4]));

	do
	{
		if (Line == "" || Line == "?")
		{
		    if (Line == "?") cout << HelpText;
			cout << ">";
			continue;
		}
		else if (Line == "q" || Line == "Q") break;
		XMLFileName      = "";            
		Slic3rName       = "Slic3r";      // Default value
		PythonScriptName = "merge.py";    // Default value
		Verbose          = "";            // Default value
		argc = 0;
		istringstream InStrStream(Line);
		while (!InStrStream.eof())
		{
			ArgV = "";
			InStrStream >> ArgV;
			if (ArgV == "") continue;
			argc++;
			if (argc == 1)      XMLFileName      = ArgV;
			else if (argc == 2) Slic3rName       = ArgV;
			else if (argc == 3) PythonScriptName = ArgV;
			else if (argc == 4) Verbose          = ArgV;
		}
		if ((ErrorMsg = GetSTLINIFileNamesFromXMLFile(XMLFileName, STLINIPairs)) == "")
		{
			if (LaunchSlic3rForSTLFiles(Slic3rName, STLINIPairs))
			    RunPythonScriptForGCODEFiles(PythonScriptName, STLINIPairs, Verbose);
			cout << "\n>";
            STLINIPairs.clear();
		}
		else
			cout << ErrorMsg << "\n\n>";
	} while (getline(cin, Line));
	return 0;
}
//---------------------------------------------------------------------------
